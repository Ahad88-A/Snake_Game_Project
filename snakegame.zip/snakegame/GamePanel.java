import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {

    private static final int SCREEN_WIDTH = 600;
    private static final int SCREEN_HEIGHT = 600;
    private static final int UNIT_SIZE = 25;
    private static final int DELAY = 100;
    
    private final LinkedList<Point> snake = new LinkedList<>();
    private Point food;
    private char direction = 'R';
    private boolean running = false;
    private Timer timer;
    private int score = 0;
    private final Random random = new Random();

    public GamePanel() {
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(Color.BLACK);
        this.setFocusable(true);
        this.addKeyListener(new KeyAdapter());
        startGame();
    }

    private void startGame() {
        snake.clear();
        // Initial snake position - centered
        int startX = (SCREEN_WIDTH / UNIT_SIZE / 2) * UNIT_SIZE;
        snake.add(new Point(startX, 0)); // Head
        snake.add(new Point(startX - UNIT_SIZE, 0));
        snake.add(new Point(startX - 2 * UNIT_SIZE, 0)); // Tail
        direction = 'R';
        score = 0;
        spawnFood();
        running = true;
        if (timer != null) {
            timer.stop();
        }
        timer = new Timer(DELAY, this);
        timer.start();
        requestFocusInWindow(); // Ensure panel has focus
    }

    private void spawnFood() {
        int x, y;
        do {
            x = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
            y = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
            food = new Point(x, y);
        } while (snake.contains(food));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    private void draw(Graphics g) {
        if (running) {
            // Draw food
            g.setColor(Color.RED);
            g.fillOval(food.x, food.y, UNIT_SIZE, UNIT_SIZE);

            // Draw snake
            for (Point p : snake) {
                g.setColor(new Color(45, 180, 0));
                g.fillRect(p.x, p.y, UNIT_SIZE, UNIT_SIZE);
                g.setColor(new Color(0, 100, 0));
                g.drawRect(p.x, p.y, UNIT_SIZE, UNIT_SIZE);
            }

            // Draw score
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("Score: " + score, 20, 30);
        } else {
            gameOver(g);
        }
    }

    private void move() {
        Point head = snake.getFirst();
        Point newHead = new Point(head);

        switch (direction) {
            case 'U' -> newHead.y -= UNIT_SIZE;
            case 'D' -> newHead.y += UNIT_SIZE;
            case 'L' -> newHead.x -= UNIT_SIZE;
            case 'R' -> newHead.x += UNIT_SIZE;
        }

        // Check collisions
        if (newHead.x < 0 || newHead.x >= SCREEN_WIDTH || 
            newHead.y < 0 || newHead.y >= SCREEN_HEIGHT || 
            snake.contains(newHead)) {
            running = false;
            timer.stop();
            return;
        }

        snake.addFirst(newHead);

        if (newHead.equals(food)) {
            score++;
            spawnFood();
        } else {
            snake.removeLast();
        }
    }

    private void gameOver(Graphics g) {
        // Game Over text
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 75));
        g.drawString("Game Over", 80, SCREEN_HEIGHT / 2);
        
        // Score text
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 40));
        g.drawString("Score: " + score, 200, SCREEN_HEIGHT / 2 + 50);
        
        // Restart instruction
        g.setFont(new Font("Arial", Font.PLAIN, 30));
        g.drawString("Press SPACE to restart", 120, SCREEN_HEIGHT / 2 + 100);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            move();
        }
        repaint();
    }

    private class KeyAdapter extends java.awt.event.KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP:
                    if (direction != 'D') direction = 'U';
                    break;
                case KeyEvent.VK_DOWN:
                    if (direction != 'U') direction = 'D';
                    break;
                case KeyEvent.VK_LEFT:
                    if (direction != 'R') direction = 'L';
                    break;
                case KeyEvent.VK_RIGHT:
                    if (direction != 'L') direction = 'R';
                    break;
                case KeyEvent.VK_SPACE:
                    if (!running) {
                        startGame();
                    }
                    break;
            }
        }
    }
}